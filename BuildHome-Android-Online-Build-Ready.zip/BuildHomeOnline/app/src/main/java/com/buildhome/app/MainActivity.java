package com.buildhome.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; int teal=Color.rgb(15,118,110), dark=Color.rgb(8,59,58), gold=Color.rgb(246,196,83);
    String[] names={"Cement","TMT Steel","Bricks","Sand","Aggregates","Blocks","Pipes","Other Materials"};
    String[] icons={"🧱","🔩","🧱","🏗️","⛰️","⬛","🪠","📦"};
    public void onCreate(Bundle b){super.onCreate(b); showHome();}
    TextView tv(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,0,0,0);return t;}
    Button btn(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setTextSize(14);b.setAllCaps(false);b.setBackgroundColor(bg);return b;}
    void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(246,248,247));setContentView(root);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); LinearLayout nav=new LinearLayout(this);nav.setPadding(4,6,4,6);nav.setBackgroundColor(Color.WHITE);String[] n={"⌂\nHome","▦\nProducts","₹\nQuote","☎\nContact"};for(String x:n){Button q=btn(x,Color.WHITE,teal);nav.addView(q,new LinearLayout.LayoutParams(0,62,1));if(x.contains("Products"))q.setOnClickListener(v->products());if(x.contains("Quote"))q.setOnClickListener(v->quote());if(x.contains("Contact"))q.setOnClickListener(v->contact());}root.addView(nav);}
    void showHome(){base(); LinearLayout top=new LinearLayout(this);top.setPadding(20,18,20,12);top.setGravity(Gravity.CENTER_VERTICAL);TextView brand=tv("BuildHome",25,Color.DKGRAY);brand.setTypeface(null,1);top.addView(brand,new LinearLayout.LayoutParams(0,70,1));top.addView(tv("VEDA ENTERPRISES • Tumkur",12,Color.GRAY)); top.addView(tv("🛒",22,teal));content.addView(top);
      TextView hero=tv("BUILDING MATERIALS\n\nEverything you need to build your home.\n\nDiscover trusted construction materials and request a quick quotation.",18,Color.WHITE);hero.setPadding(24,30,24,25);hero.setBackgroundColor(dark);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,300);hp.setMargins(18,8,18,14);content.addView(hero,hp);
      Button shop=btn("Shop materials",gold,Color.DKGRAY);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,55);sp.setMargins(30,-85,30,25);content.addView(shop,sp);shop.setOnClickListener(v->products());
      TextView h=tv("Popular materials",21,Color.DKGRAY);h.setPadding(18,12,18,10);h.setTypeface(null,1);content.addView(h);GridLayout grid=new GridLayout(this);grid.setColumnCount(2);grid.setPadding(12,0,12,20);for(int i=0;i<names.length;i++){final String name=names[i];LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,12,14,12);c.setBackgroundColor(Color.WHITE);TextView ic=tv(icons[i],42,Color.DKGRAY);c.addView(ic,new LinearLayout.LayoutParams(-1,80));TextView nm=tv(name,16,Color.DKGRAY);nm.setTypeface(null,1);c.addView(nm);Button e=btn("Enquire",Color.WHITE,teal);c.addView(e,new LinearLayout.LayoutParams(-1,45));e.setOnClickListener(v->quoteFor(name));GridLayout.LayoutParams cp=new GridLayout.LayoutParams();cp.width=0;cp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);cp.setMargins(6,6,6,6);grid.addView(c,cp);}content.addView(grid);}
    void products(){showHome();}
    void quoteFor(String item){quote(); EditText r=(EditText)content.findViewWithTag("req"); if(r!=null)r.setText("I need a quotation for "+item+".");}
    void quote(){base();content.setPadding(22,24,22,24);TextView h=tv("Request a quotation",27,Color.DKGRAY);h.setTypeface(null,1);content.addView(h);TextView p=tv("Tell us what materials you need and we'll help with pricing and delivery.",15,Color.GRAY);p.setPadding(0,8,0,18);content.addView(p);EditText name=new EditText(this);name.setHint("Your name");content.addView(name);EditText phone=new EditText(this);phone.setHint("Phone number");phone.setInputType(2);content.addView(phone);EditText req=new EditText(this);req.setHint("Materials / quantity required");req.setMinLines(5);req.setTag("req");content.addView(req);Button send=btn("Send enquiry on WhatsApp",teal,Color.WHITE);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,58);bp.setMargins(0,18,0,0);content.addView(send,bp);send.setOnClickListener(v->{String msg="Hello BuildHome, I need a quotation. Name: "+name.getText()+" Phone: "+phone.getText()+" Requirement: "+req.getText();Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text="+Uri.encode(msg)));startActivity(i);});}
    void contact(){
    new AlertDialog.Builder(this)
      .setTitle("Contact BuildHome")
      .setMessage("VEDA ENTERPRISES\nNear Ring Road, Tumkur, Karnataka\nPhone / WhatsApp: 9353086383")
      .setPositiveButton("Call", (d,w)-> startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:9353086383"))))
      .setNeutralButton("WhatsApp", (d,w)-> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/919353086383?text="+Uri.encode("Hello BuildHome, I need information about building materials.")))))
      .setNegativeButton("Maps", (d,w)-> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+Uri.encode("VEDA ENTERPRISES, Near Ring Road, Tumkur, Karnataka")))))
      .show();
}
}
