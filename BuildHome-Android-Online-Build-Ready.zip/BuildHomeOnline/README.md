# BuildHome Android — Online Build Ready

Native Android prototype for VEDA ENTERPRISES, Tumkur.

## Included
- BuildHome branding
- Construction material catalogue
- Quotation form
- WhatsApp enquiry to 9353086383
- Direct call to 9353086383
- Google Maps search for VEDA ENTERPRISES, Near Ring Road, Tumkur, Karnataka
- GitHub Actions workflow for an online APK build

## Phone-only online build
1. Create/sign in to GitHub.
2. Create a new repository named `buildhome-android`.
3. Upload all files/folders from this project, including `.github/workflows/android-build.yml`.
4. Open **Actions** → **Build BuildHome Android** → **Run workflow**.
5. Open the completed run and download the `BuildHome-debug-apk` artifact.
6. Extract it and install `app-debug.apk` on your Android phone.

## Play Store
This debug APK is for testing. Google Play requires a signed release Android App Bundle (AAB).
